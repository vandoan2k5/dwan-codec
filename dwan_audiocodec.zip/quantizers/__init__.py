from .vq import VectorQuantizeEMA
from .fsq import FSQ
from .lfq import LFQ
from .fsqste import FSQSTE